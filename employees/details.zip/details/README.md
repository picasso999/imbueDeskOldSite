# google-sheets-to-html
JavaScript that draws a Google Sheets document into an HTML table (includes base web template)

You can find more details and usage for this at my blog:
https://blog.crunchprank.net/google-sheets-to-html-table/
